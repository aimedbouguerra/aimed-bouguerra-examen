# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 14:53:39 2023

@author: sanas
"""


from tkinter import *
from Client import Client
#J'ai crée une fenetre de type tkinter
from tkinter import messagebox
Liste_Client=[]
def affiche():
    C=Client(var.get,var1.get(),var2.get(),var3.get(),var4.get(),inpuR.get())

    if inpuR.get()=="H":
     messagebox.showwarning("Info", "Bonjour Mr "+var.get() +var1.get()+"Vous avez comme age"+var2.get() +"Vous etes Bien inscrite")
    else:
        messagebox.showwarning("Info", "Bonjour Mme "+var.get() +var1.get()+"Vous avez comme age"+var2.get() +"Vous etes Bien inscrite")
    Liste_Client.append(C)
def modifier() :
     
     messagebox.showwarning("Info", "Modifcation fait avec succées")

def supprimer():
    C=Client(var.get,var1.get(),var2.get(),var3.get(),var4.get(),input.get())
    for c in Liste_Client:
        if c.nom==C.nom and c.prenom==C.prenom :
            Liste_Client.remove(c)
    messagebox.showwarning("Info", "Suppression fait avec succées")

fen=Tk()
#Rendre visible la fenetre fen
# fen.minsize(300,300)
# fen.maxsize(500,500)
fen.geometry("1000x500")

L=Label(fen,text="Gestion des données des clients",bg="pink",font=("Arial",24))
L.grid(column=2,row=0)
L1=Label(fen,text="Nom",font=("Arial",13))
L1.grid(column=0,row=1)
L2=Label(fen,text="Prenom",font=("Arial",13))
L2.grid(column=0,row=2)

L3=Label(fen,text="Age",font=("Arial",13))
L3.grid(column=0,row=3)
L4=Label(fen,text="Adreese",font=("Arial",13))
L4.grid(column=0,row=4)
L5=Label(fen,text="Numéro de téléphone",font=("Arial",13))
L5.grid(column=0,row=5)
var=StringVar()
var1=StringVar()
var2=StringVar()
var3=StringVar()
var4=StringVar()
E=Entry(fen ,text=var )
E.grid(column=1,row=1)
E1=Entry(fen ,text=var1 )
E1.grid(column=1,row=2)

E2=Entry(fen ,text=var2 )
E2.grid(column=1,row=3)
E3=Entry(fen ,text=var3 )
E3.grid(column=1,row=4)
E4=Entry(fen ,text=var4 )
E4.grid(column=1,row=5)

inpuR=StringVar()
R=Radiobutton(fen ,text="Homme",value="H",variable=inpuR)
R1=Radiobutton(fen ,text="Femme",value="F",variable=inpuR)

R.grid(column=0,row=6)
R1.grid(column=1,row=6)




B=Button(fen ,text="Ajouter",command=affiche)

B.grid(column=0,row=7)
B1=Button(fen ,text="Supprimer",command=modifier)

B1.grid(column=1,row=7)


B2=Button(fen ,text="Modifier",command=supprimer)

B2.grid(column=2,row=7)








fen.mainloop()