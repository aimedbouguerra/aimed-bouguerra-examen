class Client:
  
    compteur = 0;

    def __init__(self, nom = "Nom_Client0", prenom = "Prenom_Client0", age = 0, numero = 0, adresse = 0,genre=0):
        # Les attributs d'instance:
        self._nom = nom;
        self._prenom = prenom;
        self._age = age;
        self.numero=numero;
        self.adresse=adresse
        self.genre=genre
        Client.compteur += 1;

    # 2 types d'attributs :


    def _getNom(self):
        return self._nom;
    def _setNom(self, nom):
        self._nom = nom;
    nom = property(_getNom, _setNom);

    def _getPrenom(self):
        return self._prenom;
    def _setPrenom(self, prenom):
        self._prenom = prenom;
    prenom = property(_getPrenom, _setPrenom);

    def _getAge(self):
        return self._age;

    def _setAge(self, age):
        self._age = age;

    age = property(_getAge, _setAge);

    def _getNum(self):
        return self.numero;
    def _setNum(self,n):
       self.numero=n
    age = property(_getNum, _setNum);
  

    def _getadresse(self):
        return self.adresse;
    def _setadresse(self, adresse):
        self.adresse = adresse;
    adressese = property(_getadresse, _setadresse);
    def _getgenre(self):
      return self.genre;
    def _setgenre(self, adresse):
      self.adresse = adresse;
    genre = property(_getgenre, _setgenre);


    def Moyenne_age(L):
        s=0
        for e in L :
            s=s+e._getAge()
        m=s/Client.compteur
        return m
    def affiche(self):
     return self.nom + " "+ self.prenom + " " +str(self.age) + str(self.adresse) + " "+ str(self.numero)
                
C= Client("salim","bb")
print(C.affiche())
